/**
 * The ibis.util package provides several utilities that may be useful
 * for Ibis applications.
 */
package ibis.util;
